Buzz Christine (Windows 11)

1. Right-click the zip > Extract All (put the folder somewhere permanent, e.g. Documents).
2. Double-click 'Start Buzz.vbs'. A small window appears lower-left: speaker + 'buzz Christine'.
3. Optional: double-click 'Run at Windows startup.vbs' so it starts at sign-in.

Clicking the button buzzes Christine. While running (window or tray icon), this PC plays a loud buzz and shows '<name> is buzzing you' when someone buzzes Dennis.
Closing the window keeps it in the tray; right-click the tray icon > Exit to quit.
To change who this PC is, edit config.txt (me=).
