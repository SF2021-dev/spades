' Puts a shortcut to Start Buzz.vbs in your Startup folder so the buzz listener runs at login
Set sh = CreateObject("WScript.Shell"): Set fso = CreateObject("Scripting.FileSystemObject")
d = fso.GetParentFolderName(WScript.ScriptFullName)
Set lnk = sh.CreateShortcut(sh.SpecialFolders("Startup") & "\Diamond Spaders Buzz.lnk")
lnk.TargetPath = "wscript.exe": lnk.Arguments = """" & d & "\Start Buzz.vbs""": lnk.WorkingDirectory = d: lnk.Save
MsgBox "Buzz will now start automatically when you sign in to Windows.", 64, "Diamond Spaders Buzz"
