# Diamond Spaders desktop buzz app (Windows). Settings come from config.txt next to this file.
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfg = @{}; Get-Content (Join-Path $dir "config.txt") | ForEach-Object { if ($_ -match '^\s*(\w+)\s*=\s*(.+?)\s*$') { $cfg[$matches[1]] = $matches[2] } }
$to = $cfg.to.ToLower(); $me = $cfg.me.ToLower()
$api = if ($cfg.api) { $cfg.api } else { "https://diamondspaders.online/api/startbuzz" }
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
function Cap($s) { if (-not $s) { return "Someone" }; $s.Substring(0,1).ToUpper() + $s.Substring(1) }
$label = [char]::ConvertFromUtf32(0x1F508) + " buzz " + (Cap $to)
$wav = New-Object System.Media.SoundPlayer (Join-Path $dir "buzz.wav"); $wav.Load()

$form = New-Object Windows.Forms.Form
$form.Text = "buzz " + (Cap $to); $form.Size = New-Object Drawing.Size(220, 90)
$form.FormBorderStyle = "FixedToolWindow"; $form.TopMost = $true; $form.StartPosition = "Manual"
$wa = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Location = New-Object Drawing.Point(($wa.Left + 10), ($wa.Bottom - 100))
$btn = New-Object Windows.Forms.Button
$btn.Dock = "Fill"; $btn.Text = $label; $btn.Font = New-Object Drawing.Font("Segoe UI Emoji", 13)
$btn.BackColor = [Drawing.Color]::FromArgb(29,29,34); $btn.ForeColor = [Drawing.Color]::White; $btn.FlatStyle = "Flat"
$form.Controls.Add($btn)
$reset = New-Object Windows.Forms.Timer; $reset.Interval = 2000; $reset.Add_Tick({ $btn.Text = $label; $reset.Stop() })
$btn.Add_Click({
  try { Invoke-RestMethod -Uri $api -Method Post -ContentType "application/json" -Body (@{ to = $to; from = $me } | ConvertTo-Json) -TimeoutSec 8 | Out-Null; $btn.Text = "buzzed!" }
  catch { if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 429) { $btn.Text = "wait..." } else { $btn.Text = "failed" } }
  $reset.Start()
})

# tray icon: closing the window keeps listening in the tray
$tray = New-Object Windows.Forms.NotifyIcon
$tray.Icon = [Drawing.SystemIcons]::Information; $tray.Text = "buzz " + (Cap $to) + " (listening for " + (Cap $me) + ")"; $tray.Visible = $true
$menu = New-Object Windows.Forms.ContextMenuStrip
[void]$menu.Items.Add("Show", $null, { $form.Show(); $form.Activate() })
[void]$menu.Items.Add("Exit", $null, { $script:quit = $true; $tray.Visible = $false; [Windows.Forms.Application]::Exit() })
$tray.ContextMenuStrip = $menu; $tray.Add_DoubleClick({ $form.Show(); $form.Activate() })
$script:quit = $false
$form.Add_FormClosing({ param($s, $e) if (-not $script:quit) { $e.Cancel = $true; $form.Hide() } })

function Show-Buzz($from) {
  if ($script:ov -and -not $script:ov.IsDisposed) { $script:ov.Close() }
  $ov = New-Object Windows.Forms.Form; $script:ov = $ov
  $ov.FormBorderStyle = "None"; $ov.WindowState = "Maximized"; $ov.TopMost = $true; $ov.ShowInTaskbar = $false
  $ov.BackColor = [Drawing.Color]::Black; $ov.Opacity = 0.85
  $l = New-Object Windows.Forms.Label; $l.Dock = "Fill"; $l.TextAlign = "MiddleCenter"
  $l.Text = (Cap $from) + " is buzzing you"; $l.ForeColor = [Drawing.Color]::FromArgb(243,191,86); $l.Font = New-Object Drawing.Font("Segoe UI", 48, [Drawing.FontStyle]::Bold)
  $b = New-Object Windows.Forms.Button; $b.Text = [char]::ConvertFromUtf32(0x1F507) + "  Silence"; $b.Dock = "Bottom"; $b.Height = 110
  $b.Font = New-Object Drawing.Font("Segoe UI Emoji", 28, [Drawing.FontStyle]::Bold); $b.FlatStyle = "Flat"
  $b.BackColor = [Drawing.Color]::FromArgb(243,191,86); $b.ForeColor = [Drawing.Color]::Black
  $b.Add_Click({ try { $wav.Stop() } catch {}; $script:ov.Close() })
  $ov.Controls.Add($l); $ov.Controls.Add($b)
  $ov.Add_FormClosed({ try { $wav.Stop() } catch {} })
  # auto-close when the sound finishes (~130 s)
  $t = New-Object Windows.Forms.Timer; $t.Interval = 130000; $t.Add_Tick({ $t.Stop(); if (-not $ov.IsDisposed) { $ov.Close() } }.GetNewClosure()); $t.Start()
  $ov.Show(); $ov.Activate(); $b.Focus()
  try { $wav.Play() } catch {}
  try { Start-Process "https://messages.google.com/web/conversations" } catch {}
}

$script:last = $null
$poll = New-Object Windows.Forms.Timer; $poll.Interval = 3000
$poll.Add_Tick({
  try {
    $j = Invoke-RestMethod -Uri ("{0}?for={1}&_={2}" -f $api, $me, [DateTime]::UtcNow.Ticks) -TimeoutSec 4
    if ($script:last -ne $null -and [int64]$j.ts -gt $script:last -and ([int64]$j.now - [int64]$j.ts) -lt 20000) { Show-Buzz $j.from }
    $script:last = [int64]$j.ts
  } catch {}
})
$poll.Start()
[Windows.Forms.Application]::Run($form)
